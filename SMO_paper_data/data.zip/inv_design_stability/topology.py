from FADO import *

# Design variables
x0 = np.ndarray((76800,))
fid = open("element_properties.ini","r")
lines = fid.readlines()
fid.close()
for i in range(76800):
  x0[i] = float(lines[i+1].strip().split("  ")[-1])

rho = InputVariable(x0[2712:73224],TableWriter("  ",(2713,-1),(73225,None)),0,1.0,0.0,1.0)

options={'disp': True, 'maxcor': 10, 'ftol': 1e-8, 'gtol': 1e-12, 'maxls': 10, 'maxiter': 39}

# Parameters
# switch from direct to adjoint mode
prob_adjoint = Parameter(["DISCRETE_ADJOINT"],\
            LabelReplacer("DIRECT"))
pastix_adjoint = Parameter(["PASTIX_FACTORIZATION_FREQUENCY= 0"],\
              LabelReplacer("PASTIX_FACTORIZATION_FREQUENCY= 1"))
cfl_adjoint = Parameter(["CFL_NUMBER= 1e9"],\
           LabelReplacer("CFL_NUMBER= 300.0"))
mg_adjoint = Parameter(["MGLEVEL= 0"],\
          LabelReplacer("MGLEVEL= 3"))
fsi_iter_adj = Parameter(["FSI_ITER= 2"],\
            LabelReplacer("FSI_ITER= 1"))
restart_adj = Parameter(["RESTART_SOL= NO"],\
           LabelReplacer("RESTART_SOL= YES"))
# switch from reference node displacement to volume
func_mass = Parameter(["OBJECTIVE_FUNCTION= VOLUME_FRACTION"],\
         LabelReplacer("OBJECTIVE_FUNCTION= REFERENCE_GEOMETRY"))
func_disc = Parameter(["OBJECTIVE_FUNCTION= TOPOL_DISCRETENESS"],\
         LabelReplacer("OBJECTIVE_FUNCTION= REFERENCE_GEOMETRY"))
solver_mass = Parameter(["CONJUGATE_GRADIENT"],\
           LabelReplacer("PASTIX_LDLT"))

# Evaluations
dir_command     = "mpirun --bind-to socket -n 2 SU2_CFD settings.cfg"
dir_command_fsi = "mpirun --bind-to socket -n 2 SU2_CFD settings_fsi.cfg && rm restart_* && "+\
                  "mv solution_fluid_0.dat restart_fluid_0.dat"
adj_command     = "mpirun --bind-to socket -n 2 SU2_CFD_AD settings.cfg"
adj_command_fsi = "mpirun --bind-to socket -n 2 SU2_CFD_AD settings_fsi.cfg"
max_tries = 1

# structure with low speed reference loads
struct_low = ExternalRun("STRUCT_LOW",dir_command,True)
struct_low.setMaxTries(max_tries)
struct_low.addConfig("settings.cfg")
struct_low.addConfig("element_properties.dat")
struct_low.addData("mesh.su2")
struct_low.addData("targets/low/reference_geometry.dat")
struct_low.addData("targets/low/loads.txt")
struct_low.addExpected("restart_solid_1.dat")

# flow with current low speed displacements
flow_low = ExternalRun("FLOW_LOW",dir_command_fsi,True)
flow_low.setMaxTries(max_tries)
flow_low.addConfig("settings_fsi.cfg")
flow_low.addConfig("element_properties_1.dat")
flow_low.addData("mesh_fsi.su2")
flow_low.addData("targets/low/reference_geometry_1.dat")
flow_low.addData("targets/low/loads.txt")
flow_low.addData("targets/low/restart_fluid_0.dat")
flow_low.addData("STRUCT_LOW/restart_solid_1.dat")
flow_low.addExpected("restart_fluid_0.dat")
flow_low.addExpected("solution_solid_1.dat")

# reference geometry derivatives at low speed
struct_low_adj = ExternalRun("STRUCT_LOW_ADJ",adj_command,True)
struct_low_adj.setMaxTries(max_tries)
struct_low_adj.addConfig("settings.cfg")
struct_low_adj.addConfig("element_properties.dat")
struct_low_adj.addData("mesh.su2")
struct_low_adj.addData("targets/low/reference_geometry.dat")
struct_low_adj.addData("targets/low/loads.txt")
struct_low_adj.addData("STRUCT_LOW/restart_solid_1.dat")
struct_low_adj.addExpected("restart_adj_refgeom.dat")
struct_low_adj.addParameter(prob_adjoint)
struct_low_adj.addParameter(pastix_adjoint)

# amplification derivatives at low speed
flow_low_adj = ExternalRun("FLOW_LOW_ADJ",adj_command_fsi,True)
flow_low_adj.setMaxTries(max_tries)
flow_low_adj.addConfig("settings_fsi.cfg")
flow_low_adj.addConfig("element_properties_1.dat")
flow_low_adj.addData("mesh_fsi.su2")
flow_low_adj.addData("targets/low/reference_geometry_1.dat")
flow_low_adj.addData("targets/low/loads.txt")
flow_low_adj.addData("FLOW_LOW/restart_fluid_0.dat")
flow_low_adj.addData("STRUCT_LOW/restart_solid_1.dat")
flow_low_adj.addExpected("restart_adj_refgeom_0.dat")
flow_low_adj.addExpected("restart_adj_refgeom_1.dat")
flow_low_adj.addParameter(prob_adjoint)
flow_low_adj.addParameter(restart_adj)
flow_low_adj.addParameter(pastix_adjoint)
flow_low_adj.addParameter(fsi_iter_adj)
flow_low_adj.addParameter(cfl_adjoint)
flow_low_adj.addParameter(mg_adjoint)


# structure with high speed reference loads
struct_high = ExternalRun("STRUCT_HIGH",dir_command,True)
struct_high.setMaxTries(max_tries)
struct_high.addConfig("settings.cfg")
struct_high.addConfig("element_properties.dat")
struct_high.addData("mesh.su2")
struct_high.addData("targets/high/reference_geometry.dat")
struct_high.addData("targets/high/loads.txt")
struct_high.addExpected("restart_solid_1.dat")

# flow with current high speed displacements
flow_high = ExternalRun("FLOW_HIGH",dir_command_fsi,True)
flow_high.setMaxTries(max_tries)
flow_high.addConfig("settings_fsi.cfg")
flow_high.addConfig("element_properties_1.dat")
flow_high.addData("mesh_fsi.su2")
flow_high.addData("targets/high/reference_geometry_1.dat")
flow_high.addData("targets/high/loads.txt")
flow_high.addData("targets/high/restart_fluid_0.dat")
flow_high.addData("STRUCT_HIGH/restart_solid_1.dat")
flow_high.addExpected("restart_fluid_0.dat")
flow_high.addExpected("solution_solid_1.dat")

# reference geometry derivatives at high speed
struct_high_adj = ExternalRun("STRUCT_HIGH_ADJ",adj_command,True)
struct_high_adj.setMaxTries(max_tries)
struct_high_adj.addConfig("settings.cfg")
struct_high_adj.addConfig("element_properties.dat")
struct_high_adj.addData("mesh.su2")
struct_high_adj.addData("targets/high/reference_geometry.dat")
struct_high_adj.addData("targets/high/loads.txt")
struct_high_adj.addData("STRUCT_HIGH/restart_solid_1.dat")
struct_high_adj.addExpected("restart_adj_refgeom.dat")
struct_high_adj.addParameter(prob_adjoint)
struct_high_adj.addParameter(pastix_adjoint)

# amplification derivatives at high speed
flow_high_adj = ExternalRun("FLOW_HIGH_ADJ",adj_command_fsi,True)
flow_high_adj.setMaxTries(max_tries)
flow_high_adj.addConfig("settings_fsi.cfg")
flow_high_adj.addConfig("element_properties_1.dat")
flow_high_adj.addData("mesh_fsi.su2")
flow_high_adj.addData("targets/high/reference_geometry_1.dat")
flow_high_adj.addData("targets/high/loads.txt")
flow_high_adj.addData("FLOW_HIGH/restart_fluid_0.dat")
flow_high_adj.addData("STRUCT_HIGH/restart_solid_1.dat")
flow_high_adj.addExpected("restart_adj_refgeom_0.dat")
flow_high_adj.addExpected("restart_adj_refgeom_1.dat")
flow_high_adj.addParameter(prob_adjoint)
flow_high_adj.addParameter(restart_adj)
flow_high_adj.addParameter(pastix_adjoint)
flow_high_adj.addParameter(fsi_iter_adj)
flow_high_adj.addParameter(cfl_adjoint)
flow_high_adj.addParameter(mg_adjoint)


# volume fraction and its derivatives
vol_frac = ExternalRun("VOLUME",adj_command,True)
vol_frac.setMaxTries(max_tries)
vol_frac.addConfig("settings.cfg")
vol_frac.addConfig("element_properties.dat")
vol_frac.addData("mesh.su2")
vol_frac.addData("targets/low/reference_geometry.dat")
vol_frac.addData("targets/low/loads.txt")
vol_frac.addData("STRUCT_LOW/restart_solid_1.dat")
vol_frac.addExpected("restart_adj_volfrac.dat")
vol_frac.addParameter(func_mass)
vol_frac.addParameter(prob_adjoint)
vol_frac.addParameter(solver_mass)


# Functions
refgeo_l = Function("refgeo_l","STRUCT_LOW/of_refgeom.dat",TableReader(0,0))
refgeo_l.addInputVariable(rho,"STRUCT_LOW_ADJ/grad.dat",TableReader(None,0,(2712,0),(73224,None)))
refgeo_l.addValueEvalStep(struct_low)
refgeo_l.addGradientEvalStep(struct_low_adj)

ampl_l = Function("ampl_l","FLOW_LOW/of_refgeom.dat",TableReader(0,0))
ampl_l.addInputVariable(rho,"FLOW_LOW_ADJ/grad.dat",TableReader(None,0,(2712,0),(73224,None)))
ampl_l.addValueEvalStep(struct_low)
ampl_l.addValueEvalStep(flow_low)
ampl_l.addGradientEvalStep(flow_low_adj)

refgeo_h = Function("refgeo_h","STRUCT_HIGH/of_refgeom.dat",TableReader(0,0))
refgeo_h.addInputVariable(rho,"STRUCT_HIGH_ADJ/grad.dat",TableReader(None,0,(2712,0),(73224,None)))
refgeo_h.addValueEvalStep(struct_high)
refgeo_h.addGradientEvalStep(struct_high_adj)

ampl_h = Function("ampl_h","FLOW_HIGH/of_refgeom.dat",TableReader(0,0))
ampl_h.addInputVariable(rho,"FLOW_HIGH_ADJ/grad.dat",TableReader(None,0,(2712,0),(73224,None)))
ampl_h.addValueEvalStep(struct_high)
ampl_h.addValueEvalStep(flow_high)
ampl_h.addGradientEvalStep(flow_high_adj)

mass = Function("mass","VOLUME/of_volfrac.dat",TableReader(0,0))
mass.addInputVariable(rho,"VOLUME/grad.dat",TableReader(None,0,(2712,0),(73224,None)))
mass.addValueEvalStep(struct_low)
mass.addValueEvalStep(vol_frac)

# Driver
driver = ExteriorPenaltyDriver(0.01,0,2.0,4096.0,2.0)
driver.addObjective("min",mass,   2.5,  0.34)
driver.addObjective("min",ampl_l, 0.07, 0.33)
driver.addObjective("min",ampl_h, 4.0,  0.33)
driver.addUpperBound(refgeo_l,0.0,10.0)
driver.addUpperBound(refgeo_h,0.0,1.0)

driver.preprocessVariables()
driver.setStorageMode(True)
driver.setEvaluationMode(False,0.5)

log = open("topology.log","w",1)
his = open("topology.his","w",1)
driver.setLogger(log)
driver.setHistorian(his)

# Optimization
x  = driver.getInitial()
lb = driver.getLowerBound()
ub = driver.getUpperBound()
bounds = np.array((lb,ub),float).transpose()

def closeLogs():
  log.close()
  his.close()
#end

