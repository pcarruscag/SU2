#!/bin/bash
make clean

export CXXFLAGS="-Wno-deprecated-declarations -ftemplate-backtrace-limit=0 -O2 -std=c++11 -march=native -I{$PASTIX_523}/install -I{$EIGEN_335}"
export CPPFLAGS="-DHAVE_PASTIX -DHAVE_LAPACK -DEIGEN_NO_DEBUG -DEIGEN_DONT_PARALLELIZE"
export LDFLAGS="-L{$PASTIX_523}/install -L{$SCOTCH_606}/lib -L{$OPENBLAS}/lib"
export LIBS="-lpastix -lscotch -lptscotch -lptscotcherr -lopenblas -lhwloc -lgfortran -fopenmp"

./preconfigure.py --enable-autodiff --enable-mpi --with-cc=mpicc --with-cxx=mpicxx

make -j 8 install
