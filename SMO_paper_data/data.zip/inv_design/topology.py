from FADO import *

# Design variables
rho = InputVariable(0.75,TableWriter("  ",(2713,-1),(73225,None)),70512,1.0,0.0,1.0)

options={'disp': True, 'maxcor': 10, 'ftol': 1e-8, 'gtol': 1e-12, 'maxls': 10, 'maxiter': 39}

# Parameters
# switch from direct to adjoint mode
prob_adjoint = Parameter(["DISCRETE_ADJOINT"],\
            LabelReplacer("DIRECT"))
pastix_adjoint = Parameter(["PASTIX_FACTORIZATION_FREQUENCY= 0"],\
              LabelReplacer("PASTIX_FACTORIZATION_FREQUENCY= 1"))
# switch from reference node displacement to volume
func_mass = Parameter(["OBJECTIVE_FUNCTION= VOLUME_FRACTION"],\
         LabelReplacer("OBJECTIVE_FUNCTION= REFERENCE_GEOMETRY"))
solver_mass = Parameter(["CONJUGATE_GRADIENT"],\
           LabelReplacer("PASTIX_LDLT"))


# Evaluations
dir_command = "mpirun -n 2 SU2_CFD settings.cfg"
adj_command = "mpirun -n 2 SU2_CFD_AD settings.cfg"
max_tries = 1

# low speed
disp_dir = ExternalRun("LOW",dir_command,True)
disp_dir.setMaxTries(max_tries)
disp_dir.addConfig("settings.cfg")
disp_dir.addConfig("element_properties.dat")
disp_dir.addData("mesh.su2")
disp_dir.addData("targets/low/reference_geometry.dat")
disp_dir.addData("targets/low/loads.txt")
disp_dir.addExpected("direct.dat")

# high speed
disp_dir2 = ExternalRun("HIGH",dir_command,True)
disp_dir2.setMaxTries(max_tries)
disp_dir2.addConfig("settings.cfg")
disp_dir2.addConfig("element_properties.dat")
disp_dir2.addData("mesh.su2")
disp_dir2.addData("targets/high/reference_geometry.dat")
disp_dir2.addData("targets/high/loads.txt")
disp_dir2.addExpected("direct.dat")

# volume fraction and its derivatives
vol_frac = ExternalRun("VOLUME",adj_command,True)
vol_frac.setMaxTries(max_tries)
vol_frac.addConfig("settings.cfg")
vol_frac.addConfig("element_properties.dat")
vol_frac.addData("mesh.su2")
vol_frac.addData("targets/low/reference_geometry.dat")
vol_frac.addData("targets/low/loads.txt")
vol_frac.addData("LOW/direct.dat")
vol_frac.addExpected("restart_adj_volfrac.dat")
vol_frac.addParameter(func_mass)
vol_frac.addParameter(prob_adjoint)
vol_frac.addParameter(solver_mass)

# adjoints of ref. node displacement (low Mach)
disp_adj = ExternalRun("LOW_ADJ",adj_command,True)
disp_adj.setMaxTries(max_tries)
disp_adj.addConfig("settings.cfg")
disp_adj.addConfig("element_properties.dat")
disp_adj.addData("mesh.su2")
disp_adj.addData("targets/low/reference_geometry.dat")
disp_adj.addData("targets/low/loads.txt")
disp_adj.addData("LOW/direct.dat")
disp_adj.addExpected("restart_adj_refgeom.dat")
disp_adj.addParameter(prob_adjoint)
disp_adj.addParameter(pastix_adjoint)

# adjoints of ref. node displacement (high Mach)
disp_adj2 = ExternalRun("HIGH_ADJ",adj_command,True)
disp_adj2.setMaxTries(max_tries)
disp_adj2.addConfig("settings.cfg")
disp_adj2.addConfig("element_properties.dat")
disp_adj2.addData("mesh.su2")
disp_adj2.addData("targets/high/reference_geometry.dat")
disp_adj2.addData("targets/high/loads.txt")
disp_adj2.addData("HIGH/direct.dat")
disp_adj2.addExpected("restart_adj_refgeom.dat")
disp_adj2.addParameter(prob_adjoint)
disp_adj2.addParameter(pastix_adjoint)


# Functions
disp = Function("disp","LOW/of_refgeom.dat",TableReader(0,0))
disp.addInputVariable(rho,"LOW_ADJ/grad.dat",TableReader(None,0,(2712,0),(73224,None)))
disp.addValueEvalStep(disp_dir)
disp.addGradientEvalStep(disp_adj)

disp2 = Function("disp2","HIGH/of_refgeom.dat",TableReader(0,0))
disp2.addInputVariable(rho,"HIGH_ADJ/grad.dat",TableReader(None,0,(2712,0),(73224,None)))
disp2.addValueEvalStep(disp_dir2)
disp2.addGradientEvalStep(disp_adj2)

mass = Function("mass","VOLUME/of_volfrac.dat",TableReader(0,0))
mass.addInputVariable(rho,"VOLUME/grad.dat",TableReader(None,0,(2712,0),(73224,None)))
mass.addValueEvalStep(disp_dir)
mass.addValueEvalStep(vol_frac)

# Driver
driver = ExteriorPenaltyDriver(0.01,0,1.0,4096.0,2.0)
driver.addObjective("min",mass)
driver.addUpperBound(disp,0.0,10.0)
driver.addUpperBound(disp2,0.0,1.0)

driver.preprocessVariables()
driver.setStorageMode(False)
driver.setEvaluationMode(True,0.5)

log = open("topology.log","w",1)
his = open("topology.his","w",1)
driver.setLogger(log)
driver.setHistorian(his)

# Optimization
x  = driver.getInitial()
lb = driver.getLowerBound()
ub = driver.getUpperBound()
bounds = np.array((lb,ub),float).transpose()

def closeLogs():
  log.close()
  his.close()
#end

