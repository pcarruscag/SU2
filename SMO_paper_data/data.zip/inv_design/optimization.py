import scipy.optimize
import shutil
import math
import copy
import os

import topology


# auxilary functions
def run(obj):
  return scipy.optimize.minimize(obj.driver.fun, obj.x, method="L-BFGS-B",\
         jac=obj.driver.grad, bounds=obj.bounds, options=obj.options)
#end

def norm(v):
  return math.sqrt((v*v).sum())
#end


max_iters = 1000
history_t = [copy.deepcopy(topology.x)]

while max_iters > 0 and not topology.driver.feasibleDesign():
  optimum_t = run(topology)
  history_t.append(copy.deepcopy(optimum_t.x))
  topology.x = history_t[-1]
  topology.driver.update()

  max_iters -= optimum_t.nit
#end

topology.options["maxiter"] = max_iters
optimum_t = run(topology)
topology.driver.update()

topology.closeLogs()

